from . import const
from . import FileOp
import re
import spacy
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from tabula import read_pdf
import docx

class ResumeExtractor:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")

    def extract_personal_details(self,resume_text):
        personal_details_section = re.search(r"Personal\s*Details", resume_text, re.IGNORECASE)
        personal_details_text = ""
        if personal_details_section:
            personal_details_text = resume_text[personal_details_section.end():]
            if personal_details_text:
                lines = personal_details_text.splitlines()
            else:
                lines = resume_text.splitlines()
        else:
            lines = resume_text.splitlines()

        # Initialize variables
        name = ""
        email = ""
        phone = ""
        address = ""

        # Rule 1: Name starting with specific degrees or titles
        degree_titles = ["Dr.", "Prof.", "CA"]
        for line in lines:
            if any(line.startswith(title) for title in degree_titles):
                name = line.strip()
                break

        # Rule 2: Name under the "Name" heading
        if not name:
            name_heading_patterns = ["^Name$", "^Name:.*$"]
            for pattern in name_heading_patterns:
                match = re.search(pattern, personal_details_text, re.IGNORECASE | re.MULTILINE)
                if match:
                    name = lines[match.end()].strip()
                    break

        # Rule 3: Name at the beginning or in the middle of the resume
        if not name:
            name_lines = lines[:len(lines) // 2]
            for line in name_lines:
                if line.strip():
                    name = line.strip()
                    break

        # Rule 4: Name below a header in bold letters
        if not name:
            bold_pattern = r"<b>(.*?)</b>"
            for line in lines:
                bold_text = re.search(bold_pattern, line)
                if bold_text:
                    name = bold_text.group(1).strip()
                    break

        # Extract email using regex
    
        email_match = re.search(const.email_pattern, resume_text, re.IGNORECASE)
        if email_match:
            email = email_match.group(0)

        # Extract phone number using regex
        
        phone_match = re.search(const.phone_pattern, resume_text)
        if phone_match:
            phone = phone_match.group(0)

        # Address starting with "Address" heading
        address_heading_patterns = ["^Address$", "^Address:.*$"]
        for pattern in address_heading_patterns:
            match = re.search(pattern, resume_text, re.IGNORECASE | re.MULTILINE)
            if match:
                address_start = match.end()
                address = resume_text[address_start:].strip()
                break

        # Address containing specific keywords
        if not address:
            keywords = ["road", "colony", "city", "state"]
            for line in lines:
                if any(keyword in line.lower() for keyword in keywords):
                    address = line.strip()
                    break

        # Clean the extracted details using NLTK stopwords
        stop_words = set(stopwords.words('english'))
        name_tokens = word_tokenize(name.lower())
        name = ' '.join([w for w in name_tokens if not w in stop_words])

        # Format the extracted details
        personal_details = {
            "Name": name,
            "Email": email,
            "Phone": phone,
            "Address": address
        }
        return personal_details


    def extract_skills(self,resume_text):
        skills_heading = "SKILLS"
        current_heading = None
        current_content = ""
        is_skills_section = False
        last_heading = None  # Track the last encountered heading other than skills

        skills = []
        other_skills = []

        for line in resume_text.splitlines():
            line = line.strip()

            # Check if line starts with a skill-related keyword to consider it as a heading
            skill_keywords = ["skill", "competency", "capability", "proficiency", "knowledge", "other skills", "other skill", "TECHNICAL SKILLS", "technical skills"]
            is_heading = line.lower().startswith(tuple(skill_keywords)) and all(keyword not in line.lower() for keyword in skill_keywords[1:])

            if is_heading:
                # If it's the skills heading and we already have some content for the skills,
                # it means we have reached the end of the skills section.
                if current_heading == skills_heading and current_content.strip():
                    skills.append(current_content.strip())
                    # Reset the current content and heading.
                    current_heading = None
                    current_content = ""
                    is_skills_section = False

                # Check if the line is the skills heading to start a new skills section.
                if is_heading and current_heading != skills_heading:
                    current_heading = skills_heading
                    current_content = line + " "
                    is_skills_section = True
            elif is_skills_section:
                # Check if any non-skills heading is present in the current line,
                # which indicates the end of the skills section.
                for heading in const.headings_dictionary:
                    if any(re.search(keyword, line, re.IGNORECASE) for keyword in const.headings_dictionary[heading]):
                        last_heading = heading
                        break

                # If the last encountered heading (other than skills) is found in the current line,
                # it indicates the end of the skills section.
                if last_heading and last_heading != skills_heading:
                    # Found a heading after the skills section, consider the skills section as complete
                    skills.append(current_content.strip())
                    # Reset the current content and heading.
                    current_heading = None
                    current_content = ""
                    is_skills_section = False
                    break
                else:
                    # Skip the line if it contains "deep learning models" or "extra-curricular activities" or "certification"
                    if any(keyword in line.lower() for keyword in ["deep learning models", "extra-curricular activities", "certification"]):
                        continue
                    current_content += line + " "

        # Append the last extracted skills section (if any) when the loop finishes.
        if current_heading == skills_heading and current_content.strip():
            skills.append(current_content.strip())

        # Generate the output list with bullet points for each skill using enumerate
        bullet_points = " • "
        numbered_skills = [f"{bullet_points}{skill}" for index, skill in enumerate(skills)]

        # Search for the "Other Skills" section using the regular expression pattern
        other_skills_pattern = r"(?i)\b(?:Other\s+Skills?:?)\b([\s\S]*?)(?=\b\S+\s*?:\s*\b|$)"
        other_skills_match = re.search(other_skills_pattern, resume_text)

        # Generate the output list for other skills only if the "Other Skills" section is present
        if other_skills_match:
            other_skills_content = other_skills_match.group(1).strip()
            other_skills = [skill.strip() for skill in other_skills_content.splitlines() if skill.strip()]
            other_skills_list = ["Other Skills: " + " , ".join(other_skills)]
        else:
            other_skills_list = []

        # Search for the "Technical Skills" section using the regular expression pattern
        technical_skills_pattern = r"(?i)\b(?:Technical\s+Skills?:?)\b([\s\S]*?)(?=(?:EXPERIENCE|EDUCATION|EXTRA-CURRICULAR ACTIVITIES|CERTIFICATION|\d+:\s*SKILLS\s*|$))"
        technical_skills_match = re.search(technical_skills_pattern, resume_text)

        # Generate the output list for technical skills only if the "Technical Skills" section is present
        if technical_skills_match:
            technical_skills_content = technical_skills_match.group(1).strip()
            technical_skills = [skill.strip() for skill in technical_skills_content.splitlines() if skill.strip()]
            technical_skills_list = ["Technical Skills: " + ", ".join(technical_skills)]
        else:
            technical_skills_list = []

        return numbered_skills + other_skills_list + technical_skills_list



    def extract_education(self,resume_text):
        education_heading = "EDUCATION"
        current_heading = None
        current_content = ""
        is_education_section = False
        education = []

        # Define patterns to filter out unwanted content
        unwanted_patterns = [
            r"^Flask/Tableau/Data\s+Visualization;",
            r"^Other\s+Skills?:\s*",
            r"SAS\s*,\s*SQl\s*,\s*Weka\s*,\s*E-views\s*,\s*MS\s*Excel"
        ]
        unwanted_pattern_matcher = re.compile("|".join(unwanted_patterns), re.IGNORECASE)

        for line in resume_text.splitlines():
            line = line.strip()

            for heading, keywords in const.headings_dictionary.items():
                if any(re.search(keyword, line, re.IGNORECASE) for keyword in keywords):
                    if current_heading and current_content.strip():
                        if current_heading == education_heading and not unwanted_pattern_matcher.match(current_content):
                            is_education_section = True
                            education.append(current_content.strip())
                        else:
                            is_education_section = False
                            break

                    current_heading = heading
                    current_content = ""
                    break

            if current_heading == education_heading or is_education_section:
                if line:
                    current_content += line + "\n"
                else:
                    # If we encounter an empty line, it indicates the end of the current section
                    if current_heading == education_heading:
                        is_education_section = False

        if current_heading == education_heading and current_content.strip() and not unwanted_pattern_matcher.match(current_content):
            education.append(current_content.strip())

        return education

    def extract_experience(self,resume_text):
        current_heading = None
        current_title = None
        current_content = ""
        is_experience_section = False
        is_education_section = False
        experience_entries = []
        entry_indices = {}  # Dictionary to store entry indices for each title

        # Indicators that suggest skill section starts
        skill_section_indicators = ["Skills:", "Languages:", "Technologies:", "Technical Skills:"]
        
        # Indicators that suggest education section starts
        education_section_indicators = ["Education", "Educational Qualifications", "Academic Background"]

    
        for line in resume_text.splitlines():
            line = line.strip()

            if any(indicator in line for indicator in skill_section_indicators):
                break

            for heading, keywords in const.headings_dictionary.items():
                if any(re.search(keyword, line, re.IGNORECASE) for keyword in keywords):
                    if current_heading and current_content.strip() and current_heading == "EXPERIENCE":
                        is_experience_section = True
                        experience_entries.append(current_content.strip())

                    current_heading = heading
                    current_content = ""
                    current_title = line  # Update the current title
                    entry_indices[current_title] = 1  # Initialize the entry index for the new title
                    break

            if current_heading == "EXPERIENCE" or is_experience_section:
                
                if any(indicator in line for indicator in education_section_indicators):
                    is_education_section = True  # Start of education section
                    is_experience_section = False  # Exclude lines in the education section
                elif is_education_section and line:  # Skip lines in the education section
                    continue
                elif not any(keyword in line for keyword in ["Mob:", "Phone:", "Email:", "Address:", "Deadline", "Profile", "Certified"]) \
                        and not re.search(const.phone_pattern, line) \
                        and not re.search(const.email_pattern, line):
                    if line.startswith(""):  # Replace cross mark with bullet point character
                        line = f"• {line[1:].strip()}"
                    current_content += line + "\n"

        if current_heading == "EXPERIENCE" and current_content.strip():
            experience_entries.append(current_content.strip())
        
        # Reset entry_indices for each title
        entry_indices = {}

        return experience_entries




    def extract_career_objective(self,resume_text, file_extension):
    
        if file_extension.lower() == 'docx':
            return ResumeExtractor.extract_career_objective_from_docx(self,resume_text)
        else:
            # Use the previous method for other file formats
            nlp = spacy.load("en_core_web_sm")
            doc = nlp(resume_text)

            career_objective = []
            objective_found = False

            career_objective_keywords = ["career", "objective", "summary", "profile summary", "career goal", "career focus","RESUME OBJECTIVE","resume objective"]

            for sentence in doc.sents:
                for token in sentence:
                    if token.text.lower() in career_objective_keywords:
                        objective_found = True
                        break

                if objective_found:
                    career_objective.append(sentence.text)
                    break

            # Join the extracted sentences to form the career objective
            career_objective_text = " ".join(career_objective)

            # Exclude the phone number from the career objective
            phone_pattern = re.compile(r'(\d{10})')
            career_objective_cleaned = re.sub(phone_pattern, "", career_objective_text)

            return career_objective_cleaned.strip()


    def extract_career_objective_from_docx(self,file_path):
        document = docx.Document(file_path)
        career_objective_text = ""
        for paragraph in document.paragraphs:
            paragraph_text = paragraph.text.strip()
            if any(keyword in paragraph_text.lower() for keyword in ["career", "objective", "summary", "profile"]):
                career_objective_text += paragraph_text + "\n"

        return career_objective_text.strip()


    def extract_extra_curricular(self,resume_text):
        extra_curricular_heading = "EXTRA_CURRICULAR"
        current_heading = None
        current_content = ""
        is_extra_curricular_section = False
        extra_curricular = []

        for line in resume_text.splitlines():
            line = line.strip()

            for heading, keywords in const.headings_dictionary.items():
                if any(re.search(keyword, line, re.IGNORECASE) for keyword in keywords):
                    if current_heading and current_content.strip():
                        if current_heading == extra_curricular_heading:
                            is_extra_curricular_section = True
                            extra_curricular.append(current_content.strip())
                        else:
                            is_extra_curricular_section = False
                            break

                    current_heading = heading
                    current_content = ""
                    break

            if current_heading == extra_curricular_heading or is_extra_curricular_section:
                if line:
                    current_content += line + "\n"

        if current_heading == extra_curricular_heading and current_content.strip():
            extra_curricular.append(current_content.strip())

        return extra_curricular


    def extract_declaration(self,resume_text):
        declaration_heading = "DECLARATION"
        current_heading = None
        current_content = ""
        is_declaration_section = False
        declaration = []

        for line in resume_text.splitlines():
            line = line.strip()

            for heading, keywords in const.headings_dictionary.items():
                if any(re.search(keyword, line, re.IGNORECASE) for keyword in keywords):
                    if current_heading and current_content.strip():
                        if current_heading == declaration_heading:
                            is_declaration_section = True
                            declaration.append(current_content.strip())
                        else:
                            is_declaration_section = False
                            break

                    current_heading = heading
                    current_content = ""
                    break

            if current_heading == declaration_heading or is_declaration_section:
                if line:
                    current_content += line + "\n"

        if current_heading == declaration_heading and current_content.strip():
            declaration.append(current_content.strip())

        return declaration


    def extract_certifications(self,resume_text):
        certifications_heading = "CERTIFICATIONS"
        current_heading = None
        current_content = ""
        is_certifications_section = False
        certifications = []

        for line in resume_text.splitlines():
            line = line.strip()

            for heading, keywords in const.headings_dictionary.items():
                if any(re.search(keyword, line, re.IGNORECASE) for keyword in keywords):
                    if current_heading and current_content.strip():
                        if current_heading == certifications_heading:
                            is_certifications_section = True
                            certifications.append(current_content.strip())
                        else:
                            is_certifications_section = False
                            break

                    current_heading = heading
                    current_content = ""
                    break

            if current_heading == certifications_heading or is_certifications_section:
                if line:
                    current_content += line + "\n"

        if current_heading == certifications_heading and current_content.strip():
            certifications.append(current_content.strip())

        return certifications


def validate_emails(extracted_data):
    # Define a regular expression pattern to match email addresses
    email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
    # Find all the email addresses in the extracted data
    emails = email_pattern.findall(extracted_data)
    # If there is at least one email address, return the first one
    if emails:
        return emails[0]
    # If there are no email addresses, return None
    return None


def validate_phone_numbers(extracted_data):
    # Define a regular expression pattern to match phone numbers
    phone_pattern = re.compile(r'(\d{10})')
    # Find all the phone numbers in the extracted data
    phone_numbers = phone_pattern.findall(extracted_data)
    # If there is at least one phone number, return the first one
    if phone_numbers:
        return phone_numbers[0]
    # If there are no phone numbers, return None
    return None



def extract_name_from_resume(extracted_data):
    nlp = spacy.load("en_core_web_sm")
    doc = nlp(extracted_data)
    names = []
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            names.append(ent.text)

    if names:
        return names[0]
    else:
        return ""



def clean_text(text):
    # Define unwanted bullet points
    unwanted_symbols = ['\uf0b7', '\uf0d8']
    
    # Remove extra spaces or lines after bullet points
    for symbol in unwanted_symbols:
        # Split the text based on the bullet point
        parts = text.split(symbol)
        # Process each part separately
        for i in range(1, len(parts)):
            # Remove leading spaces or lines from the next part
            parts[i] = parts[i].lstrip('\n ')
            # Remove empty lines
            if parts[i].startswith('\n'):
                parts[i] = parts[i].lstrip('\n')
        # Join the parts back together
        text = symbol.join(parts)
    
    # Unwrap text after full stop or bullet point
    text = re.sub(r'(?<=[\.\uf0b7\uf0d8])\n\s*', ' ', text)  # Remove line breaks after full stop or bullet point
    
    # Define filters for sections to remove
    filters = ["Skills:", "Languages:", "Technologies:", "Technical Skills:", "Certifications:", "Education:"]
    if "EXPERIENCE" in text.upper():
        for section in filters:
            if section in text:
                text = text.split(section, 1)[0]  # Remove the section and everything after it
                break
    
    return text

