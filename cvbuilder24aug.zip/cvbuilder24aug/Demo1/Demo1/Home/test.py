
from tabula import read_pdf
import fitz
import re
import tabula
headings_dictionary = {
    "EDUCATION": [
        "academic background", "Educational Summary", "educational qualifications",
        "educational history", "academic credentials", "education credentials",
        "academic record", "formal education", "educational highlights",
        "educational background", "degrees and certifications", "education", 
        "professional education", "education and degrees", "educational accomplishments", 
        "qualifications and education", "Professional & Academic Qualifications", 
        "Others Skills", "other skills","education", "degree", "qualification", "academics"
    ],

    "SKILLS": [
        "skills", "core competencies", "key skills", "technical proficiencies", 
        "areas of expertise", "technical skills", "software proficiencies", 
        "specialized skills", "professional skills", "language proficiencies", 
        "industry knowledge", "tools and technologies", "functional skills", 
        "leadership skills", "relevant skills", "Technical Skills"
    ],

    "EXPERIENCE": [
        "experience", "Work Experience", "experiences", "projects", 
        "project experience", "project highlights", "project portfolio", 
        "project involvement", "project work", "project details", 
        "project management", "Employment History", "employment history"
        "experience", "work", "job", "position", "project", "Undertaken Projects", "undertaken projects"
    ],

    "CERTIFICATIONS": [
        "certification", "certifications", "professional certifications", 
        "certification highlights", "certified achievements", "credentialing", 
        "certifications and licenses", "industry certifications", 
        "certification portfolio", "certified expertise", "certified skills", 
        "certification credentials", "certification accomplishments", 
        "certification training", "certified proficiencies", 
        "certified specializations", "accredited certifications", 
        "industry-recognized certifications", 
        "certified training and development", "validated certifications", 
        "extra-curricular activities & certification"
    ],

    "CAREER_OBJECTIVE": [
        "career", "Personal Traits", "objective", "CAREER OBJECTIVE", 
        "career objective", "career", "objective", "professional summary", 
        "career summary", "profile", "career profile", "professional profile", 
        "overview", "summary of qualifications", "career highlights", 
        "career goals", "personal statement", "value proposition", "career focus", 
        "career objectives", "professional goals", "introduction", "Career Objective", 
        "Objective", "Career Summary", "Professional Profile", "RESUME OBJECTIVE", 
        "resume objective"
    ],

    "EXTRA_CURRICULAR": [
        "extra-curricular", "Member & Alumnus of Professional & Academic Bodies", 
        "Activities", "activities and involvement", "leadership experience", 
        "volunteering and community engagement", "community service", 
        "professional development", "skills and interests", "relevant hobbies", 
        "additional engagements", "special projects", "personal initiatives", 
        "non-academic pursuits", "club memberships", "campus involvement", 
        "team memberships", "creative pursuits", "athletics and sports", 
        "social and cultural activities", "philanthropy and fundraising", 
        "entrepreneurial ventures", "professional affiliations", 
        "undertaken projects", "activitie", "activities", "Activities""extra-curricular activities"
    ],

    "DECLARATION": [
        "declaration", "professional affirmation", "personal statement", 
        "commitment statement", "career pledge", "ethical declaration", 
        "statement of integrity", "career promise", "professional vow", 
        "professional code", "career commitment", "statement of professionalism", 
        "values statement", "professional oath", "professional assurance", 
        "career dedication", "ethical pledge", "personal integrity statement", 
        "career ethics statement", "career mission statement", 
        "professional conduct statement"
    ]
}

def extract_pdf_data(uploaded_file):
    with fitz.open(uploaded_file) as pdf:
        text_pages = []
        for page in pdf:
            text = page.get_text("text")
            text_pages.append(text)
        full_text = "\n".join(text_pages)
        dfs = tabula.read_pdf(uploaded_file, pages='all')
        for i in range(len(dfs)):
            full_text += '\n\n' + str(dfs[i])
        return full_text
    
def extract_experience(resume_text):
        
        email_pattern = r"[\w\.-]+@[\w\.-]+"
        phone_pattern = r"(\+\d{1,2}\s?)?(\()?\d{3}(\))?[-.\s]?\d{3}[-.\s]?\d{4}"


        current_heading = None
        current_title = None
        current_content = ""
        is_experience_section = False
        is_education_section = False
        experience_entries = []
        entry_indices = {}  # Dictionary to store entry indices for each title

        # Indicators that suggest skill section starts
        skill_section_indicators = ["Skills:", "Languages:", "Technologies:", "Technical Skills:"]
        
        # Indicators that suggest education section starts
        education_section_indicators = ["Education", "Educational Qualifications", "Academic Background"]

    


        for line in resume_text.splitlines():
            line = line.strip()

            if any(indicator in line for indicator in skill_section_indicators):
                break

            for heading, keywords in headings_dictionary.items():
                if any(re.search(keyword, line, re.IGNORECASE) for keyword in keywords):
                    if current_heading and current_content.strip() and current_heading == "EXPERIENCE":
                        is_experience_section = True
                        experience_entries.append(current_content.strip())

                    current_heading = heading
                    current_content = ""
                    current_title = line  # Update the current title
                    entry_indices[current_title] = 1  # Initialize the entry index for the new title
                    break

            if current_heading == "EXPERIENCE" or is_experience_section:
                
                if any(indicator in line for indicator in education_section_indicators):
                    is_education_section = True  # Start of education section
                    is_experience_section = False  # Exclude lines in the education section
                elif is_education_section and line:  # Skip lines in the education section
                    continue
                elif not any(keyword in line for keyword in ["Mob:", "Phone:", "Email:", "Address:", "Deadline", "Profile", "Certified"]) \
                        and not re.search(phone_pattern, line) \
                        and not re.search(email_pattern, line):
                    if line.startswith(""):  # Replace cross mark with bullet point character
                        line = f"• {line[1:].strip()}"
                    current_content += line + "\n"

        if current_heading == "EXPERIENCE" and current_content.strip():
            experience_entries.append(current_content.strip())
        
        # Reset entry_indices for each title
        entry_indices = {}

        return experience_entries
 
def remove_paragraph_spaces(text):
    # Split text into paragraphs using multiple newlines followed by any whitespace characters
    paragraphs = re.split(r'\n\s*\n\s*', text)
    
    # Remove leading and trailing spaces from each paragraph
    paragraphs = [p.strip() for p in paragraphs]
    
    # Reconstruct the text without extra spaces between paragraphs
    cleaned_text = '\n\n'.join(paragraphs)
    
    return cleaned_text



uploaded_file="C:\\Users\\vrathod\\Downloads\\ramakrishna_1.pdf"
extracted_text=extract_pdf_data(uploaded_file)
experience=extract_experience(extracted_text)
if isinstance(experience, str):
    cleaned_experience = remove_paragraph_spaces(experience)
    print(cleaned_experience)
else:
    print("Experience text should be a string or bytes-like object.")
#exp=remove_paragraph_spaces(experience)
# exp=remove_skills_section(experience)
# expp=remove_certificates_section(experience)
#print(exp)
