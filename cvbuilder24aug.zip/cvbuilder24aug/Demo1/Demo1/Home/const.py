from . import project
headings_dictionary = {
    "EDUCATION": [
        "academic background", "Educational Summary", "educational qualifications",
        "educational history", "academic credentials", "education credentials",
        "academic record", "formal education", "educational highlights",
        "educational background", "degrees and certifications", "education", 
        "professional education", "education and degrees", "educational accomplishments", 
        "qualifications and education", "Professional & Academic Qualifications", 
        "Others Skills", "other skills","education", "degree", "qualification", "academics"
    ],

    "SKILLS": [
        "skills", "core competencies", "key skills", "technical proficiencies", 
        "areas of expertise", "technical skills", "software proficiencies", 
        "specialized skills", "professional skills", "language proficiencies", 
        "industry knowledge", "tools and technologies", "functional skills", 
        "leadership skills", "relevant skills", "Technical Skills"
    ],

    "EXPERIENCE": [
         "Work Experience", "experiences", "projects", 
        "project experience", "project highlights", "project portfolio", 
        "project involvement", "project work", "project details", 
        "project management", "Employment History", "employment history"
        "experience", "work", "job", "position", "project", "Undertaken Projects", "undertaken projects"
    ],

    "CERTIFICATIONS": [
        "certification", "certifications", "professional certifications", 
        "certification highlights", "certified achievements", "credentialing", 
        "certifications and licenses", "industry certifications", 
        "certification portfolio", "certified expertise", "certified skills", 
        "certification credentials", "certification accomplishments", 
        "certification training", "certified proficiencies", 
        "certified specializations", "accredited certifications", 
        "industry-recognized certifications", 
        "certified training and development", "validated certifications", 
        "extra-curricular activities & certification"
    ],

    "CAREER_OBJECTIVE": [
        "career", "Personal Traits", "objective", "CAREER OBJECTIVE", 
        "career objective", "career", "objective", "professional summary", 
        "career summary", "profile", "career profile", "professional profile", 
        "overview", "summary of qualifications", "career highlights", 
        "career goals", "personal statement", "value proposition", "career focus", 
        "career objectives", "professional goals", "introduction", "Career Objective", 
        "Objective", "Career Summary", "Professional Profile", "RESUME OBJECTIVE", 
        "resume objective"
    ],

    "EXTRA_CURRICULAR": [
        "extra-curricular", "Member & Alumnus of Professional & Academic Bodies", 
        "Activities", "activities and involvement", "leadership experience", 
        "volunteering and community engagement", "community service", 
        "professional development", "skills and interests", "relevant hobbies", 
        "additional engagements", "special projects", "personal initiatives", 
        "non-academic pursuits", "club memberships", "campus involvement", 
        "team memberships", "creative pursuits", "athletics and sports", 
        "social and cultural activities", "philanthropy and fundraising", 
        "entrepreneurial ventures", "professional affiliations", 
        "undertaken projects", "activitie", "activities", "Activities""extra-curricular activities"
    ],

    "DECLARATION": [
        "declaration", "professional affirmation", "personal statement", 
        "commitment statement", "career pledge", "ethical declaration", 
        "statement of integrity", "career promise", "professional vow", 
        "professional code", "career commitment", "statement of professionalism", 
        "values statement", "professional oath", "professional assurance", 
        "career dedication", "ethical pledge", "personal integrity statement", 
        "career ethics statement", "career mission statement", 
        "professional conduct statement"
    ]
}

email_pattern = r"[\w\.-]+@[\w\.-]+"
phone_pattern = r"(\+\d{1,2}\s?)?(\()?\d{3}(\))?[-.\s]?\d{3}[-.\s]?\d{4}"
HTTP_POST='POST'
