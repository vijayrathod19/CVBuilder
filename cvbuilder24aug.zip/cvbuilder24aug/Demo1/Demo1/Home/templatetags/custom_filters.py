# from django import template
# from django.utils.html import mark_safe

# register = template.Library()

# @register.filter
# def highlight_job_title(text):
#     # Define keywords to highlight
#     keywords = ["Jan.", "Feb.", "Mar.", "Apr.", "May", "Jun.", "Jul.", "Aug.", "Sep.", "Oct.", "Nov.", "Dec.", "Present"]

#     # Split text into lines and process each line
#     highlighted_lines = []
#     for line in text.splitlines():
#         for keyword in keywords:
#             if keyword in line:
#                 # Apply highlighting to the keyword using inline HTML <span>
#                 line = line.replace(keyword, f'<span class="highlight">{keyword}</span>')
#         highlighted_lines.append(line)

#     # Join the lines and mark the result as safe HTML
#     return mark_safe('\n'.join(highlighted_lines))


# date highliting well

# import re
# from django import template
# from django.utils.html import mark_safe

# register = template.Library()

# @register.filter
# def highlight_job_title(text):
#     lines = text.splitlines()
#     result = []

#     # Regular expression pattern to match a month and year pattern like "Mar. 2020"
#     month_year_pattern = re.compile(r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+\d{4}\b')

#     for line in lines:
#         # Find all matches of month and year in the line
#         matches = re.findall(month_year_pattern, line)

#         # Highlight each match in the line
#         for match in matches:
#             line = line.replace(match, f'<span class="highlight">{match}</span>')

#         result.append(line)

#     return mark_safe('\n'.join(result))



# import re
# from django import template
# from django.utils.html import mark_safe

# register = template.Library()

# @register.filter
# def highlight_job_title(text):
#     lines = text.splitlines()
#     result = []

#     # Regular expression pattern to match a month and year pattern like "Mar. 2020"
#     month_year_pattern = re.compile(r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+\d{4}\b')

#     for line in lines:
#         # Find all matches of month and year in the line
#         date_matches = re.findall(month_year_pattern, line)

#         # Highlight each date match in the line
#         for date_match in date_matches:
#             line = line.replace(date_match, f'<span class="highlight">{date_match}</span>')

#         # Extract the company title
#         company_title = re.split(month_year_pattern, line, maxsplit=1)[0].strip()
        
#         # Highlight the company title in the line
#         if company_title:
#             line = line.replace(company_title, f'<span class="highlight">{company_title}</span>')

#         result.append(line)

#     return mark_safe('\n'.join(result))


#well perfectly

# import re
# from django import template
# from django.utils.html import mark_safe

# register = template.Library()

# @register.filter
# def highlight_job_title(text):
#     lines = text.splitlines()
#     result = []

#     # Regular expression pattern to match a month and year pattern like "Mar. 2020"
#     month_year_pattern = re.compile(r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+\d{4}\b')

#     for line in lines:
#         # Find all matches of month and year in the line
#         date_matches = re.findall(month_year_pattern, line)

#         # Highlight each date match in the line
#         for date_match in date_matches:
#             line = line.replace(date_match, f'<span class="highlight">{date_match}</span>')

#         # Find all matches of job titles (company titles) in the line
#         job_title_matches = re.findall(r'[\w\s]+,\s[\w\s]+\.', line)

#         # Highlight each job title match in the line
#         for job_title_match in job_title_matches:
#             line = line.replace(job_title_match, f'<span class="highlight">{job_title_match}</span>')

#         result.append(line)

#     return mark_safe('\n'.join(result))



# import re
# from django import template
# from django.utils.html import mark_safe

# register = template.Library()

# @register.filter
# def highlight_job_title(text):
#     lines = text.splitlines()
#     result = []

#     # Regular expression pattern to match a job title, company name, and date range
#     job_info_pattern = re.compile(r'([^:]+): ([^(]+)\(([^–-]+–[^)]+)\)')

#     for line in lines:
#         # Find all matches of job title, company name, and date range in the line
#         job_info_matches = re.findall(job_info_pattern, line)

#         # Iterate through the matches
#         for job_info_match in job_info_matches:
#             job_title, company_name, date_range = job_info_match

#             # Create a highlighted version of the match
#             highlighted_match = f'{job_title}: <span class="highlight">{company_name} ({date_range})</span>'

#             # Replace the match with the highlighted version in the line
#             line = line.replace(f'{job_info_match[0]}: {job_info_match[1]}({job_info_match[2]})', highlighted_match)

#         result.append(line)

#     return mark_safe('\n'.join(result))






# import re
# from django import template
# from django.utils.html import mark_safe

# register = template.Library()

# @register.filter
# def highlight_job_title(text):
#     lines = text.splitlines()
#     result = []

#     # Regular expression pattern to match a job title, company name, and date range
#     job_info_pattern = re.compile(r'([^:]+): ([^(]+)\(([^–-]+(?: – Present|\d{4}(?: – \d{4}| – [A-Z][a-z]+ \d{4})))\)')

#     # Regular expression pattern to match a month and year pattern like "Mar. 2020" with optional single quotes
#     month_year_pattern = re.compile(r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+[‘’]?\d{2,4}\b')

#     within_job_entry = False

#     for line in lines:
#         if re.search(job_info_pattern, line):
#             within_job_entry = True
#             job_info_matches = re.findall(job_info_pattern, line)
#             for job_info_match in job_info_matches:
#                 job_title, company_name, date_range = job_info_match
#                 highlighted_match = f'{job_title}: <span class="highlight">{company_name} ({date_range})</span>'
#                 line = line.replace(f'{job_info_match[0]}: {job_info_match[1]}({job_info_match[2]})', highlighted_match)
#         elif within_job_entry:
#             line = f'<span class="highlight">{line}</span>'

#         # Find all matches of month and year in the line
#         date_matches = re.findall(month_year_pattern, line)

#         # Highlight each date match in the line
#         for date_match in date_matches:
#             line = line.replace(date_match, f'<span class="highlight">{date_match}</span>')

#         result.append(line)

#     return mark_safe('\n'.join(result))



import re
from django import template
from django.utils.html import mark_safe
from django.utils.safestring import mark_safe

register = template.Library()

@register.filter(name='remove_successive_bullets')
def remove_successive_bullets(value):
    # Replace successive bullets with a single bullet
    value = re.sub(r'&#8226;{2,}', '&#8226;', value)

    # Adjust text when a bullet point is not followed by text on the same line
    value = re.sub(r'&#8226;\s*(?![^\n]*\S)', '', value)

    # Replace "" with a bullet point followed by a space
    value = re.sub(r'', '&#8226; ', value)
    
    # Add a bullet point before each paragraph
    paragraphs = value.split('\n')
    bulleted_text = '&#8226; ' + '&#8226; '.join(paragraphs)
    
    return mark_safe(bulleted_text)

@register.filter
def highlight_job_title(text):
    lines = text.splitlines()
    result = []

    # Regular expression pattern to match a month and year pattern like "Mar. 2020"
    month_year_pattern = re.compile(r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?\s+\d{4}\b')

    for line in lines:
        # Find all matches of month and year in the line and make them bold with light blue color
        line = re.sub(month_year_pattern, r'<span class="highlight" style="color: red;"><strong>\g<0></strong></span>', line)

        # Find all matches of job titles (company titles) in the line and make them bold with light blue color
        job_title_pattern = re.compile(r'[\w\s]+,\s[\w\s]+\.')
        line = re.sub(job_title_pattern, r'<span class="highlight" style="color: black;"><strong>\g<0></strong></span>', line)

        # Find all matches of numbers in the line and make them bold with light blue color
        number_pattern = re.compile(r'\b\d+\b')
        line = re.sub(number_pattern, r'<span class="highlight" style="color: blue;"><strong>\g<0></strong></span>', line)

        result.append(line)

    return mark_safe('\n'.join(result))
