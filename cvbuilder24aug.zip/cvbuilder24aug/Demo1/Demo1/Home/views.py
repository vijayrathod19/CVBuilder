from django.shortcuts import render, HttpResponse
from Home.models import DemoModel
from . import const
from . import FileOp
from . import project
import nltk
import tempfile


def SignupPage(request):
    return render(request,'signup.html')

def LoginPage(request):
    return render(request,'login.html')



class ResumeView:
    @staticmethod
    def get_context_data():
        demo_data = DemoModel.objects.all().latest('id')
        context = {
            'name': demo_data.name,
            'email': demo_data.email,
            'phone': demo_data.phone,
            'career_objective': demo_data.career_objective,
            'skills': demo_data.skills,
            'work_experience': demo_data.work_experience,
            'eductional_summary': demo_data.eductional_summary,
            'certification': demo_data.certification,
            'personal_details': demo_data.personal_details,
            'declaration': demo_data.declaration,
            'extra_curricular': demo_data.extra_curricular
        }
        return context

    @staticmethod
    def resume_view(request):
        context = ResumeView.get_context_data()
        return render(request, 'resume.html', context=context)

    @staticmethod
    def doc_resume_view(request):
        context = ResumeView.get_context_data()
        return render(request, 'docresume.html', context=context)

    @staticmethod
    def ppt_resume_view(request):
        context = ResumeView.get_context_data()
        return render(request, 'ppt.html', context=context)


def upload_file(request):
    valid_phone_number = ""
    if request.method == const.HTTP_POST:
        nltk.download('stopwords')
        nltk.download('punkt')
    
    if 'file' in request.FILES:
        # Get the uploaded file from the request
        uploaded_file = request.FILES['file']
        
        # Save the file to a temporary file on disk
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(uploaded_file.read())
            file_path = f.name
        
        # Determine the file type by examining the file extension
        file_extension = uploaded_file.name.split('.')[-1]
        
       
        extracted_data = FileOp.FileOp.extract_text_data(file_path, file_extension)

        CV=project.ResumeExtractor()

        if file_extension == 'pdf':
            clean_data = FileOp.FileOp.extract_pdf_data(file_path)
            extracted_data = project.clean_text(clean_data)
            extracted_data
        elif file_extension == 'doc' or file_extension == 'docx':
            extracted_data = FileOp.FileOp.extract_word_data(file_path)
        elif file_extension == 'txt':
            extracted_data = FileOp.FileOp.extract_text_data(file_path)
        else:
            return HttpResponse('Unsupported file type')
        
        career_objective = CV.extract_career_objective(extracted_data, file_extension)
        # Write the extracted data to a new text file
        with open('extracted_data.txt', 'w', encoding='utf-8') as f:
            f.write(extracted_data)
        
        # Extract personal details
        personal_details = CV.extract_personal_details(extracted_data)
        valid_email = project.validate_emails(extracted_data)
        valid_phone_number = project.validate_phone_numbers(extracted_data)
        
        # Extract name from resume
        name = project.extract_name_from_resume(extracted_data)
        
        # Extract skills
        skills = CV.extract_skills(extracted_data)
        
        # Extract education
        education = CV.extract_education(extracted_data)
        
        # Extract experience
        experience = CV.extract_experience(extracted_data)
        
        # Extract extra-curricular activities
        extra_curricular = CV.extract_extra_curricular(extracted_data)
        
        # Extract declaration
        declaration = CV.extract_declaration(extracted_data)
        
        # Extract certifications
        certifications = CV.extract_certifications(extracted_data)
        
        # Extract career objectives
        career_objective = CV.extract_career_objective(extracted_data, file_extension)
        
        # creating model/database instance
        ins = DemoModel(
            name=name,
            email=valid_email,
            phone=valid_phone_number,
            skills=";".join(skills),
            work_experience=";".join(experience),
            eductional_summary=";".join(education),
            certification=";".join(certifications),
            personal_details=personal_details,
            declaration=";".join(declaration),
            extra_curricular=";".join(extra_curricular),
            career_objective=career_objective
        )
        ins.save()

        return render(request, "selectformat.html")

    return render(request, 'upload.html')


