from django.contrib import admin
from Home.models import DemoModel

# Register your models here.

admin.site.register(DemoModel)