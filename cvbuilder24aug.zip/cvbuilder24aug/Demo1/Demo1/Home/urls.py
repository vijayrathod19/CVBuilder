from django.contrib import admin
from django.urls import path
from .views import upload_file, LoginPage, SignupPage
from .views import ResumeView

urlpatterns = [
    path('',LoginPage,name='LoginPage'),
    path('login/',LoginPage,name='LoginPage'),
    path('signup/',SignupPage,name='SignupPage'),
    path('upload/', upload_file ,name='upload_file'),
     path('resume/', ResumeView.resume_view, name='resume'),
    path('doc_resume/', ResumeView.doc_resume_view, name='doc_resume'),
    path('ppt_resume/', ResumeView.ppt_resume_view, name='ppt_resume'),
    
]
