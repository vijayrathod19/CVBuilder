import fitz
import tabula
from tabula import read_pdf
import docx
class FileOp:
    def extract_pdf_data(uploaded_file):
        with fitz.open(uploaded_file) as pdf:
            text_pages = []
            for page in pdf:
                text = page.get_text("text")
                text_pages.append(text)
            full_text = "\n".join(text_pages)
            dfs = tabula.read_pdf(uploaded_file, pages='all')
            for i in range(len(dfs)):
                full_text += '\n\n' + str(dfs[i])
            return full_text

    def extract_word_data(file_path):
        document = docx.Document(file_path)
        data = []
        for paragraph in document.paragraphs:
            data.append(paragraph.text)
        return "\n".join(data)

    def extract_docx_data(file_path):
        document = docx.Document(file_path)
        data = []
        for paragraph in document.paragraphs:
            data.append(paragraph.text)
        return "\n".join(data)

    def extract_plain_text_data(file_path):
        with open(file_path, "r") as file:
            data = file.read()
        return data

    def extract_text_data(file_path, file_extension):
        if file_extension == 'pdf':
            return FileOp.extract_pdf_data(file_path)
        elif file_extension == 'docx':
            return FileOp.extract_docx_data(file_path)
        elif file_extension == 'txt':
            return FileOp.extract_plain_text_data(file_path)
        else:
            raise ValueError("Unsupported file type")

